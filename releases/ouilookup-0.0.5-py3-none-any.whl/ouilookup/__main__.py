from .ouilookup import main

main()
